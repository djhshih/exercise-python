# Structure of The Neural Network Solution

For this exercise we propose a more general solution. We do this because there is no especification on for which dataset are we building this model, so we add variables to adapt this model to different datasets. The solution is separated in 3 scripts. The main script is `NeuralNetwork.py` where we have defined a class to consider this model as a python object, with flexible hyperparameters. In the script `utils.py` we have defined some basic functions that are used on the model. Finally, we build an example for the digits dataset of scikit-learn.

We have only used the `numpy` tools, and the model has implemented a training function to fit the model on a specific data with the backpropagation of errors algorithm. The weights are inicialized randomly with a normal distribution N(0,1) and normalized in function of the dimension of the input, the inputs are also normalized.

In order to the model be able of read the data, the data must be stored in a list with the following format:
```
data = [(np.array(n,),label),(np.array(n,),label),...]
```

The model uses a cross entropy error with a softmax function as the last activation fucntion to obtain the "probabilities" of each label.

For any doubt contact me on: mciudadbosch@gmail.com.