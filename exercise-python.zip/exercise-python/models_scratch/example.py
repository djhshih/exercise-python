import NeuralNetwork as NN
import numpy as np
from sklearn.datasets import load_digits, load_iris
from utils import *

digits = load_digits()
# iris = load_iris()

X = digits.data
y = digits.target
n = len(X)
labels = len(list(set(y)))

# We normalize data
max = 0
for x in X: 
    if np.max(x) > max: max = np.max(x)

data = [(np.array(X[i])/max, int(y[i])) for i in range(n)]

data_train, data_test = split(data, 0.8)
n0 = len(X[0])

model = NN.NeuralNetwork(n0, labels, 2, [64,  24], ['Sigmoind', 'ReLU'])
print(model)


print(f"\n\033[1mTraining size: \033[0m\t{len(data_train)}")
print(f"\033[1mTest size: \033[0m\t{len(data_test)}\n")
model.train(data_train, 100, learning_rate=0.01)

acc = model.test(data_test)

print(f"\033[1;32mPrecision\033[0m: {acc}\n")



